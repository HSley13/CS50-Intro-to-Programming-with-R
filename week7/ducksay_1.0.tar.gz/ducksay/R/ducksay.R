ducksay <- function(phrase = "Hello, World") {
    base::paste( # nolint
        phrase, # nolint
        ">(. )__",
        " (_____/",
        sep = "\n"
    ) # nolint
}
